// Definitions for sprite sheet game_02
// Created with www.texturepacker.com

// $TexturePacker:SmartUpdate:2a00a5795a2e1e35e429b6c3453bbd7f$

package Texture;

public interface game_02
{
	public static final int GAME_BG_ID = 0;
}
