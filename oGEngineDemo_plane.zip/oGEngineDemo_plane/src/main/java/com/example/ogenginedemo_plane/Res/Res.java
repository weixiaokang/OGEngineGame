package com.example.ogenginedemo_plane.Res;

public class Res {

	public static final String XML_GFX_SHOOT = "gfx/shoot.xml";

	public static final String[] ALL_XML = new String[]{
		Res.XML_GFX_SHOOT
	};

	public static final String BENEMY = "Benemy";

	public static final String MENEMY = "Menemy";

	public static final String SENEMY = "SEnemy";

	public static final String BG = "bg";

	public static final String BOMB = "bomb";

	public static final String BOOM = "boom";

	public static final String BT_BOMB = "bt_bomb";

	public static final String BULLET = "bullet";

	public static final String BULLET1 = "bullet1";

	public static final String BULLET2 = "bullet2";

	public static final String ET = "et";

	public static final String GAME_MEDAL = "game_medal";

	public static final String GAME_OVER = "game_over";

	public static final String GAME_RESULT_BG = "game_result_bg";

	public static final String GAME_START = "game_start";

	public static final String PLANE = "plane";

	public static final String START = "start";

	public static final String STOP = "stop";

}