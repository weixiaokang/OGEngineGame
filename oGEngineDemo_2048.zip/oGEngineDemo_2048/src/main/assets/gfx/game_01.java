// Definitions for sprite sheet game_01
// Created with www.texturepacker.com

// $TexturePacker:SmartUpdate:c770310bd4fd78aa45a8458e3b998489$

package Texture;

public interface game_01
{
	public static final int GAME_BTN_EXIT_01_ID = 0;
	public static final int GAME_BTN_EXIT_02_ID = 1;
	public static final int GAME_BTN_HELP_01_ID = 2;
	public static final int GAME_BTN_HELP_02_ID = 3;
	public static final int GAME_HELP_BG_ID = 4;
	public static final int GAME_LOGO_ID = 5;
	public static final int GAME_RECT_BG_ID = 6;
	public static final int GAME_ROUNDRECT_ID = 7;
	public static final int GAME_SCORE_BG_BEST_ID = 8;
	public static final int GAME_SCORE_BG_NOW_ID = 9;
}
