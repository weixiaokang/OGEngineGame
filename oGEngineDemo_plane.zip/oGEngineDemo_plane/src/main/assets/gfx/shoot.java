// Definitions for sprite sheet shoot
// Created with www.texturepacker.com

// $TexturePacker:SmartUpdate:67c67092e42c49f8a6392f4cdca11021$

package Texture;

public interface shoot
{
	public static final int BENEMY_01_ID = 0;
	public static final int BENEMY_02_ID = 1;
	public static final int BENEMY_03_ID = 2;
	public static final int BENEMY_04_ID = 3;
	public static final int BENEMY_05_ID = 4;
	public static final int BENEMY_06_ID = 5;
	public static final int BENEMY_07_ID = 6;
	public static final int BENEMY_08_ID = 7;
	public static final int BENEMY_09_ID = 8;
	public static final int MENEMY_01_ID = 9;
	public static final int MENEMY_02_ID = 10;
	public static final int MENEMY_03_ID = 11;
	public static final int MENEMY_04_ID = 12;
	public static final int MENEMY_05_ID = 13;
	public static final int SENEMY_01_ID = 14;
	public static final int SENEMY_02_ID = 15;
	public static final int SENEMY_03_ID = 16;
	public static final int SENEMY_04_ID = 17;
	public static final int SENEMY_05_ID = 18;
	public static final int BG_ID = 19;
	public static final int BOMB_ID = 20;
	public static final int BOOM_ID = 21;
	public static final int BT_BOMB_ID = 22;
	public static final int BULLET_ID = 23;
	public static final int BULLET1_ID = 24;
	public static final int BULLET2_ID = 25;
	public static final int ET_01_ID = 26;
	public static final int ET_02_ID = 27;
	public static final int ET_03_ID = 28;
	public static final int ET_04_ID = 29;
	public static final int GAME_MEDAL_01_ID = 30;
	public static final int GAME_MEDAL_02_ID = 31;
	public static final int GAME_MEDAL_03_ID = 32;
	public static final int GAME_MEDAL_04_ID = 33;
	public static final int GAME_OVER_ID = 34;
	public static final int GAME_RESULT_BG_ID = 35;
	public static final int GAME_START_01_ID = 36;
	public static final int PLANE_01_ID = 37;
	public static final int PLANE_02_ID = 38;
	public static final int PLANE_03_ID = 39;
	public static final int PLANE_04_ID = 40;
	public static final int PLANE_05_ID = 41;
	public static final int PLANE_06_ID = 42;
	public static final int START_1_ID = 43;
	public static final int START_2_ID = 44;
	public static final int START_3_ID = 45;
	public static final int STOP_01_ID = 46;
	public static final int STOP_02_ID = 47;
}
